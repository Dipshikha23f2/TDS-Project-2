#  Badly  Formatted  Markdown    

*  This is an uneven list
* With inconsistent spacing
   *    And weird indentation

>This quote has no space
>   This one has too many

L0bgG jkfLzO 4 Y wJugMHc yrbW bWXHlg A 0H4Y 
y7Z   Ug8T  P nc28CdntM T KMdJMry  dy ZtOCmL8od SKpL GGPL9
4YyaD  bkNcTg7Mf81a  LF0UJi6JTajY KAF9WCj1oLbj  p0 k cqIlJlb4v1ay4T Tm  1Zg If8wQJ 5RPXX 6jKm2xzSyILe v0fru w ZTrIyD 0DAXSAyyw d6TT Y t Exk w65v2vVyZ XAgoG F0Ee mvwg 2GTyrvOGH  vMVum4Mn L4wZ
 dTaF